package com.radiantlogic.custom.dataconnector;

import com.radiantlogic.iddm.request.LdapSearchRequest;
import com.radiantlogic.iddm.response.LdapResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class HarryPotterOpenapiDataConnectorTest {

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private HarryPotterOpenapiDataConnector dataConnector;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        // Initialize dataConnector with a mock API base URL
        dataConnector = new HarryPotterOpenapiDataConnector("http://example.com/api", null);
    }

    @Test
    void testSearchHousesSuccess() {
        // Mock the API response
        HarryPotterOpenapiDataConnector.House[] mockHouses = {
                new HarryPotterOpenapiDataConnector.House() {{
                    id = "1";
                    name = "Gryffindor";
                }}
        };
        ResponseEntity<HarryPotterOpenapiDataConnector.House[]> mockResponse = new ResponseEntity<>(mockHouses, HttpStatus.OK);
        when(restTemplate.getForEntity(any(String.class), eq(HarryPotterOpenapiDataConnector.House[].class))).thenReturn(mockResponse);

        // Create a search request
        LdapSearchRequest searchRequest = new LdapSearchRequest();
        searchRequest.setBaseDn("houses");
        searchRequest.setAttributes(Collections.emptyMap());

        // Perform the search
        ResponseEntity<LdapResponse> response = dataConnector.search(searchRequest);

        // Assert the results
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("success", response.getBody().getStatus());
    }

    @Test
    void testSearchHousesFailure() {
        // Mock the API response for failure
        ResponseEntity<HarryPotterOpenapiDataConnector.House[]> mockResponse = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        when(restTemplate.getForEntity(any(String.class), eq(HarryPotterOpenapiDataConnector.House[].class))).thenReturn(mockResponse);

        // Create a search request
        LdapSearchRequest searchRequest = new LdapSearchRequest();
        searchRequest.setBaseDn("houses");
        searchRequest.setAttributes(Collections.emptyMap());

        // Perform the search
        ResponseEntity<LdapResponse> response = dataConnector.search(searchRequest);

        // Assert the results
        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("error", response.getBody().getStatus());
    }

    @Test
    void testTestConnectionSuccess() {
        // Mock the API response for success
        when(restTemplate.getForEntity(any(String.class), eq(String.class))).thenReturn(new ResponseEntity<>("OK", HttpStatus.OK));

        // Perform the test connection
        ResponseEntity<com.radiantlogic.iddm.response.TestConnectionResponse> response = dataConnector.testConnection(null);

        // Assert the results
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("success", response.getBody().getStatus());
    }

    @Test
    void testTestConnectionFailure() {
        // Mock the API response for failure
        when(restTemplate.getForEntity(any(String.class), eq(String.class))).thenReturn(new ResponseEntity<>("Error", HttpStatus.INTERNAL_SERVER_ERROR));

        // Perform the test connection
        ResponseEntity<com.radiantlogic.iddm.response.TestConnectionResponse> response = dataConnector.testConnection(null);

        // Assert the results
        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("error", response.getBody().getStatus());
    }
}