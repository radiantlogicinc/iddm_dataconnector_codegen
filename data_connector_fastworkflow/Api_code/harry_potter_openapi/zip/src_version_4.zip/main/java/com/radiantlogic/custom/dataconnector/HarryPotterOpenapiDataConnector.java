package com.radiantlogic.custom.dataconnector;

import com.radiantlogic.iddm.base.annotation.CustomConnector;
import com.radiantlogic.iddm.base.annotation.Property;
import com.radiantlogic.iddm.base.component.ManagedComponent;
import com.radiantlogic.iddm.base.logging.Logger;
import com.radiantlogic.iddm.operation.SearchOperations;
import com.radiantlogic.iddm.operation.TestConnectionOperations;
import com.radiantlogic.iddm.request.LdapSearchRequest;
import com.radiantlogic.iddm.request.TestConnectionRequest;
import com.radiantlogic.iddm.response.LdapResponse;
import com.radiantlogic.iddm.response.TestConnectionResponse;
import com.radiantlogic.iddm.base.ReadOnlyProperties;
import com.radiantlogic.iddm.base.InjectableProperties;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@CustomConnector(metaJsonFile = "harry_potter_openapiConnector.json")
public class HarryPotterOpenapiDataConnector implements SearchOperations, TestConnectionOperations {

    private static final Logger logger = Logger.getLogger(HarryPotterOpenapiDataConnector.class);
    private final HarryPotterOpenapiClient housesApiClient;
    private final ReadOnlyProperties properties;

    @ManagedComponent
    public HarryPotterOpenapiDataConnector(@Property(name = "api_base_url") String apiBaseUrl, InjectableProperties properties) {
        this.housesApiClient = new HarryPotterOpenapiClient(apiBaseUrl);
        this.properties = properties;
    }

    @Override
    public ResponseEntity<LdapResponse> search(LdapSearchRequest searchRequest) {
        try {
            String objectType = searchRequest.getBaseDn(); // Assuming baseDn contains the object type (e.g., "houses")
            Map<String, String> attributes = searchRequest.getAttributes();

            if ("houses".equalsIgnoreCase(objectType)) {
                return housesApiClient.searchHouses(attributes);
            } else {
                return ResponseEntity.badRequest().body(new LdapResponse("error", "Unsupported object type: " + objectType));
            }
        } catch (Exception e) {
            logger.error("Error during search: ", e);
            return ResponseEntity.internalServerError().body(new LdapResponse("error", "Search failed: " + e.getMessage()));
        }
    }

    @Override
    public ResponseEntity<TestConnectionResponse> testConnection(TestConnectionRequest request) {
        try {
            // Test connection to houses endpoint
            ResponseEntity<String> housesResponse = housesApiClient.testConnection();
            if (housesResponse.getStatusCode().is2xxSuccessful()) {
                return ResponseEntity.ok(new TestConnectionResponse("success", "Connection to Harry Potter API successful."));
            } else {
                return ResponseEntity.status(housesResponse.getStatusCode())
                        .body(new TestConnectionResponse("error", "Connection to Harry Potter API failed: " + housesResponse.getStatusCodeValue()));
            }
        } catch (Exception e) {
            logger.error("Error testing connection: ", e);
            return ResponseEntity.internalServerError().body(new TestConnectionResponse("error", "Connection test failed: " + e.getMessage()));
        }
    }

    // API Client for Houses
    static class HarryPotterOpenapiClient {
        private final String apiBaseUrl;
        private final RestTemplate restTemplate;

        public HarryPotterOpenapiClient(String apiBaseUrl) {
            this.apiBaseUrl = apiBaseUrl;
            this.restTemplate = new RestTemplate();
        }

        public ResponseEntity<LdapResponse> searchHouses(Map<String, String> attributes) {
            try {
                UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(apiBaseUrl + "/houses");
                if (attributes != null && !attributes.isEmpty()) {
                    for (Map.Entry<String, String> entry : attributes.entrySet()) {
                        builder.queryParam(entry.getKey(), entry.getValue());
                    }
                }
                ResponseEntity<House[]> response = restTemplate.getForEntity(builder.toUriString(), House[].class);
                if (response.getStatusCode().is2xxSuccessful()) {
                    List<Map<String, Object>> houseList = new ArrayList<>();
                    if (response.getBody() != null) {
                        for (House house : response.getBody()) {
                            Map<String, Object> houseMap = new HashMap<>();
                            houseMap.put("id", house.id);
                            houseMap.put("name", house.name);
                            houseMap.put("mascot", house.mascot);
                            houseMap.put("headOfHouse", house.headOfHouse);
                            houseMap.put("houseGhost", house.houseGhost);
                            houseMap.put("founder", house.founder);
                            houseMap.put("school", house.school);
                            houseMap.put("members", house.members);
                            houseMap.put("values", house.values);
                            houseMap.put("colors", house.colors);
                            houseList.add(houseMap);
                        }
                    }
                    return ResponseEntity.ok(new LdapResponse("success", houseList));
                } else {
                    return ResponseEntity.status(response.getStatusCode())
                            .body(new LdapResponse("error", "API request failed: " + response.getStatusCodeValue()));
                }
            } catch (Exception e) {
                logger.error("Error searching houses: ", e);
                return ResponseEntity.internalServerError().body(new LdapResponse("error", "Search failed: " + e.getMessage()));
            }
        }

        public ResponseEntity<String> testConnection() {
            try {
                return restTemplate.getForEntity(apiBaseUrl + "/houses/random", String.class);
            } catch (Exception e) {
                logger.error("Error testing connection: ", e);
                throw e;
            }
        }
    }

    // Data classes for Houses
    static class House {
        public String id;
        public String name;
        public String mascot;
        public String headOfHouse;
        public String houseGhost;
        public String founder;
        public String school;
        public String[] members;
        public String[] values;
        public String[] colors;
    }
}