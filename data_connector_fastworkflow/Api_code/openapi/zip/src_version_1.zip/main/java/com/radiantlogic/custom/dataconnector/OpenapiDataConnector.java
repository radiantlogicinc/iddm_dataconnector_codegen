package com.radiantlogic.custom.dataconnector.openapiapi;

import com.radiantlogic.iddm.sdk.annotations.CustomConnector;
import com.radiantlogic.iddm.sdk.annotations.ManagedComponent;
import com.radiantlogic.iddm.sdk.annotations.Properties;
import com.radiantlogic.iddm.sdk.connector.ReadOperations;
import com.radiantlogic.iddm.sdk.connector.TestConnectionOperations;
import com.radiantlogic.iddm.sdk.model.request.SearchRequest;
import com.radiantlogic.iddm.sdk.model.response.ResponseEntity;
import com.radiantlogic.iddm.sdk.model.response.ResponseStatus;
import com.radiantlogic.iddm.sdk.model.config.ConnectionConfiguration;
import com.radiantlogic.iddm.sdk.model.config.NamingContextProperties;
import com.radiantlogic.iddm.sdk.model.config.SchemaCollection;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Unified OpenAPI connector – implements LDAP Search and Test‑Connection operations.
 */
@CustomConnector(metaJsonFile = "openapiConnector.json")
public class OpenapiDataConnector implements
        ReadOperations<SearchRequest>,
        TestConnectionOperations<SearchRequest> {

    private static final Pattern OPERATION_FILTER_PATTERN =
            Pattern.compile("\\(operation=([^\\)]+)\\)", Pattern.CASE_INSENSITIVE);

    private final ConnectionConfiguration connectionConfig;
    private final OpenapiHttpClient httpClient;
    private final String basePath; // optional, derived from configuration

    public OpenapiDataConnector(
            @Properties(name = "CONNECTION_CONFIGURATION") ConnectionConfiguration connectionConfig,
            @Properties(name = "SCHEMA") SchemaCollection schemas,
            @Properties(name = "NAMING_CONTEXT") NamingContextProperties namingContext,
            @Properties(name = "BASE_PATH") String basePath) {
        this.connectionConfig = connectionConfig;
        this.basePath = (basePath != null && !basePath.isEmpty()) ? basePath : "";
        this.httpClient = new OpenapiHttpClient(connectionConfig);
    }

    /**
     * LDAP Search – the filter must contain an attribute named {@code operation}
     * whose value matches one of the {@code source_object} values defined in the
     * OpenAPI description (e.g. {@code login}, {@code authenticate}, etc.).
     */
    @Override
    public ResponseEntity<?> search(SearchRequest searchRequest) {
        String operation = extractOperationFromFilter(searchRequest.getFilter());
        if (operation == null) {
            return new ResponseEntity<>(ResponseStatus.INVALID_REQUEST,
                    Collections.singletonList("Missing required filter attribute 'operation'"));
        }

        EndpointInfo endpoint = EndpointRegistry.getEndpoint(operation);
        if (endpoint == null) {
            return new ResponseEntity<>(ResponseStatus.NOT_FOUND,
                    Collections.singletonList("Unsupported operation: " + operation));
        }

        // Build full URL
        String url = connectionConfig.getHostname() + basePath + endpoint.path;

        // Resolve path parameters (e.g., {account}, {service_id}) from the LDAP filter if present.
        url = resolvePathParameters(url, searchRequest.getFilter());

        // Prepare headers – for this skeleton we only forward the Accept‑Encoding header if present.
        Map<String, String> headers = extractHeadersFromFilter(searchRequest.getFilter());

        // No request body for GET; for POST we could forward a placeholder body (not needed for demo).
        String body = null;

        String rawResponse = httpClient.callApi(url, endpoint.verb, headers, body);

        return new ResponseEntity<>(ResponseStatus.OK,
                Collections.singletonList(rawResponse));
    }

    /**
     * Simple test‑connection implementation – performs a lightweight GET to the
     * root of the configured host to verify reachability.
     */
    @Override
    public ResponseEntity<?> testConnection(SearchRequest request) {
        String url = connectionConfig.getHostname() + basePath + "/healthz";
        try {
            httpClient.callApi(url, "GET", Collections.emptyMap(), null);
            return new ResponseEntity<>(ResponseStatus.OK,
                    Collections.singletonList("Connection successful"));
        } catch (Exception e) {
            return new ResponseEntity<>(ResponseStatus.CONNECTION_ERROR,
                    Collections.singletonList(e.getMessage()));
        }
    }

    /* --------------------------------------------------------------------- */
    /* Helper methods                                                       */
    /* --------------------------------------------------------------------- */

    private String extractOperationFromFilter(String filter) {
        if (filter == null) return null;
        Matcher m = OPERATION_FILTER_PATTERN.matcher(filter);
        return m.find() ? m.group(1) : null;
    }

    private String resolvePathParameters(String url, String filter) {
        // Very naive implementation: replace {param} with a value extracted from the filter
        // e.g. filter contains (account=dev) -> replace {account} with dev
        Pattern paramPattern = Pattern.compile("\\(([^=]+)=([^\\)]+)\\)");
        Matcher m = paramPattern.matcher(filter);
        Map<String, String> values = new HashMap<>();
        while (m.find()) {
            values.put(m.group(1), m.group(2));
        }
        for (Map.Entry<String, String> e : values.entrySet()) {
            url = url.replace("{" + e.getKey() + "}", e.getValue());
        }
        return url;
    }

    private Map<String, String> extractHeadersFromFilter(String filter) {
        // For demo purposes we only look for Accept-Encoding header in the filter:
        // (Accept-Encoding=base64)
        Map<String, String> headers = new HashMap<>();
        Pattern hdrPattern = Pattern.compile("\\((Accept-Encoding)=([^\\)]+)\\)", Pattern.CASE_INSENSITIVE);
        Matcher m = hdrPattern.matcher(filter);
        if (m.find()) {
            headers.put(m.group(1), m.group(2));
        }
        return headers;
    }

    /* --------------------------------------------------------------------- */
    /* Static registry of endpoint metadata (derived from target_json)       */
    /* --------------------------------------------------------------------- */

    private static final class EndpointInfo {
        final String path;
        final String verb;

        EndpointInfo(String path, String verb) {
            this.path = path;
            this.verb = verb;
        }
    }

    private static final class EndpointRegistry {
        private static final Map<String, EndpointInfo> MAP = new HashMap<>();

        static {
            // Populated from target_json.methods[].source_object
            MAP.put("login", new EndpointInfo("/authn/{account}/login", "GET"));
            MAP.put("login-ldap", new EndpointInfo("/authn-ldap/{service_id}/{account}/login", "GET"));
            MAP.put("inject_client_cert", new EndpointInfo("/authn-k8s/{service_id}/inject_client_cert", "POST"));
            MAP.put("authenticate", new EndpointInfo("/authn/{account}/{login}/authenticate", "POST"));
            MAP.put("authenticate-gcp", new EndpointInfo("/authn-gcp/{account}/authenticate", "POST"));
            MAP.put("authenticate-oidc", new EndpointInfo("/authn-oidc/{service_id}/{account}/authenticate", "POST"));
            MAP.put("authenticate-jwt", new EndpointInfo("/authn-jwt/{service_id}/{account}/authenticate", "POST"));
            MAP.put("authn-iam", new EndpointInfo("/authn-iam/{service_id}/{account}/{login}/authenticate", "POST"));
            MAP.put("authn-azure", new EndpointInfo("/authn-azure/{service_id}/{account}/{login}/authenticate", "POST"));
        }

        static EndpointInfo getEndpoint(String operation) {
            // The operation name in the filter may be the raw source_object or a
            // simplified alias; we try both.
            EndpointInfo info = MAP.get(operation);
            if (info != null) return info;
            // fallback for aliases used in the target_json (e.g., "authenticate" covers multiple)
            if ("authenticate".equals(operation)) return MAP.get("authenticate");
            if ("authn-iam".equals(operation)) return MAP.get("authn-iam");
            if ("authn-azure".equals(operation)) return MAP.get("authn-azure");
            return null;
        }
    }
}

/* --------------------------------------------------------------------- */
/* Managed HTTP client – simple wrapper around java.net.HttpURLConnection   */
/* --------------------------------------------------------------------- */
@ManagedComponent
class OpenapiHttpClient {

    private final ConnectionConfiguration config;

    OpenapiHttpClient(ConnectionConfiguration config) {
        this.config = config;
    }

    /**
     * Executes an HTTP request against the configured host.
     *
     * @param url     Full URL (including protocol, host, path)
     * @param verb    HTTP method (GET, POST, …)
     * @param headers Optional request headers
     * @param body    Optional request body (for POST/PUT)
     * @return The raw response body as a String
     */
    String callApi(String url, String verb, Map<String, String> headers, String body) {
        // In a real implementation you would use a robust HTTP client (Apache HttpClient,
        // OkHttp, etc.). For brevity we provide a very small stub that can be mocked in tests.
        throw new UnsupportedOperationException("HTTP client not implemented – mock in tests");
    }
}
```

---