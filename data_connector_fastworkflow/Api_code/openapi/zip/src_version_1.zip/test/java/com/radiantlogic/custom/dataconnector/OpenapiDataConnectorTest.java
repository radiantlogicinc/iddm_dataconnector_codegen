package com.radiantlogic.custom.dataconnector.openapiapi;

import com.radiantlogic.iddm.sdk.model.request.SearchRequest;
import com.radiantlogic.iddm.sdk.model.response.ResponseEntity;
import com.radiantlogic.iddm.sdk.model.response.ResponseStatus;
import com.radiantlogic.iddm.sdk.model.config.ConnectionConfiguration;
import com.radiantlogic.iddm.sdk.model.config.SchemaCollection;
import com.radiantlogic.iddm.sdk.model.config.NamingContextProperties;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;

import java.util.Collections;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OpenapiDataConnectorTest {

    @Mock
    private ConnectionConfiguration mockConfig;

    @Mock
    private SchemaCollection mockSchemas;

    @Mock
    private NamingContextProperties mockNamingContext;

    @Mock
    private OpenapiHttpClient mockHttpClient;

    @InjectMocks
    private OpenapiDataConnector connector;

    @BeforeEach
    void setUp() {
        // The connector constructor creates its own OpenapiHttpClient instance.
        // We replace it via reflection for testability.
        connector = new OpenapiDataConnector(mockConfig, mockSchemas, mockNamingContext, "/api");
        // inject the mocked http client
        try {
            java.lang.reflect.Field clientField = OpenapiDataConnector.class.getDeclaredField("httpClient");
            clientField.setAccessible(true);
            clientField.set(connector, mockHttpClient);
        } catch (Exception e) {
            fail("Failed to inject mock HttpClient: " + e.getMessage());
        }

        when(mockConfig.getHostname()).thenReturn("https://conjur.example.com");
    }

    @Test
    void testSearch_loginOperation_success() throws Exception {
        // Build a SearchRequest whose filter requests the "login" operation for account "dev"
        String filter = "(&(operation=login)(account=dev))";
        SearchRequest request = new SearchRequest();
        request.setFilter(filter);

        // Expected URL after placeholder substitution
        String expectedUrl = "https://conjur.example.com/api/authn/dev/login";

        // Mock HTTP client response
        when(mockHttpClient.callApi(eq(expectedUrl), eq("GET"), anyMap(), isNull()))
                .thenReturn("{\"api_key\":\"abcd1234\"}");

        // Execute
        ResponseEntity<?> response = connector.search(request);

        // Verify HTTP client was called correctly
        verify(mockHttpClient, times(1))
                .callApi(eq(expectedUrl), eq("GET"), anyMap(), isNull());

        // Assert response
        assertEquals(ResponseStatus.OK, response.getStatus());
        assertTrue(response.getData() instanceof java.util.List);
        @SuppressWarnings("unchecked")
        java.util.List<String> data = (java.util.List<String>) response.getData();
        assertEquals(1, data.size());
        assertEquals("{\"api_key\":\"abcd1234\"}", data.get(0));
    }

    @Test
    void testSearch_missingOperation_returnsInvalidRequest() {
        String filter = "(account=dev)";
        SearchRequest request = new SearchRequest();
        request.setFilter(filter);

        ResponseEntity<?> response = connector.search(request);

        assertEquals(ResponseStatus.INVALID_REQUEST, response.getStatus());
        assertTrue(((java.util.List<?>) response.getData()).get(0).toString()
                .contains("Missing required filter attribute 'operation'"));
    }

    @Test
    void testTestConnection_success() throws Exception {
        String healthUrl = "https://conjur.example.com/api/healthz";
        when(mockHttpClient.callApi(eq(healthUrl), eq("GET"), anyMap(), isNull()))
                .thenReturn("OK");

        ResponseEntity<?> response = connector.testConnection(new SearchRequest());

        assertEquals(ResponseStatus.OK, response.getStatus());
        assertEquals("Connection successful", ((java.util.List<?>) response.getData()).get(0));
    }

    @Test
    void testTestConnection_failure() throws Exception {
        String healthUrl = "https://conjur.example.com/api/healthz";
        when(mockHttpClient.callApi(eq(healthUrl), eq("GET"), anyMap(), isNull()))
                .thenThrow(new RuntimeException("Timeout"));

        ResponseEntity<?> response = connector.testConnection(new SearchRequest());

        assertEquals(ResponseStatus.CONNECTION_ERROR, response.getStatus());
        assertTrue(((java.util.List<?>) response.getData()).get(0).toString()
                .contains("Timeout"));
    }
}
```

---