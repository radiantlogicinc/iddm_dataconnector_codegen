package com.radiantlogic.custom.dataconnector;

import com.radiantlogic.iddm.base.ReadOnlyProperties;
import com.radiantlogic.iddm.request.LdapSearchRequest;
import com.radiantlogic.iddm.request.TestConnectionRequest;
import com.radiantlogic.iddm.response.LdapResponse;
import com.radiantlogic.iddm.response.TestConnectionResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class HarryPotterOpenapiDataConnectorTest {

    @Mock
    private ReadOnlyProperties properties;

    @Mock
    private Client client;

    @Mock
    private WebTarget webTarget;

    @Mock
    private Invocation.Builder builder;

    @Mock
    private Response response;

    @InjectMocks
    private HarryPotterOpenapiDataConnector dataConnector;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        when(properties.getString("api_base_url")).thenReturn("http://example.com");
        when(client.target(anyString())).thenReturn(webTarget);
        when(webTarget.request()).thenReturn(builder);
        when(builder.get()).thenReturn(response);
    }

    @Test
    void testSearchBooks() throws Exception {
        // Arrange
        LdapSearchRequest request = new LdapSearchRequest("books", "title:Harry");
        Map<String, Object> book = new HashMap<>();
        book.put("title", "Harry Potter and the Sorcerer's Stone");
        List<Map<String, Object>> expectedResults = Collections.singletonList(book);
        when(response.getStatus()).thenReturn(200);
        when(response.readEntity(List.class)).thenReturn(expectedResults);

        // Act
        LdapResponse response = dataConnector.search(request);

        // Assert
        assertEquals(200, response.getStatusCode());
        assertEquals(expectedResults, response.getData());
        verify(client, times(1)).target("http://example.com/books");
    }

    @Test
    void testSearchCharacters() throws Exception {
        // Arrange
        LdapSearchRequest request = new LdapSearchRequest("characters", "name:Harry");
        Map<String, Object> character = new HashMap<>();
        character.put("name", "Harry Potter");
        List<Map<String, Object>> expectedResults = Collections.singletonList(character);
        when(response.getStatus()).thenReturn(200);
        when(response.readEntity(List.class)).thenReturn(expectedResults);

        // Act
        LdapResponse response = dataConnector.search(request);

        // Assert
        assertEquals(200, response.getStatusCode());
        assertEquals(expectedResults, response.getData());
        verify(client, times(1)).target("http://example.com/characters");
    }

    @Test
    void testSearchSpells() throws Exception {
        // Arrange
        LdapSearchRequest request = new LdapSearchRequest("spells", "name:Accio");
        Map<String, Object> spell = new HashMap<>();
        spell.put("name", "Accio");
        List<Map<String, Object>> expectedResults = Collections.singletonList(spell);
        when(response.getStatus()).thenReturn(200);
        when(response.readEntity(List.class)).thenReturn(expectedResults);

        // Act
        LdapResponse response = dataConnector.search(request);

        // Assert
        assertEquals(200, response.getStatusCode());
        assertEquals(expectedResults, response.getData());
        verify(client, times(1)).target("http://example.com/spells");
    }

    @Test
    void testSearchUnsupportedObjectType() {
        // Arrange
        LdapSearchRequest request = new LdapSearchRequest("houses", "name:Gryffindor");

        // Act
        LdapResponse response = dataConnector.search(request);

        // Assert
        assertEquals(400, response.getStatusCode());
        assertEquals("Unsupported object type", response.getData());
    }

    @Test
    void testTestConnectionSuccess() throws Exception {
        // Arrange
        TestConnectionRequest request = new TestConnectionRequest();
        when(response.getStatus()).thenReturn(200);

        // Act
        TestConnectionResponse response = dataConnector.testConnection(request);

        // Assert
        assertEquals(200, response.getStatusCode());
        assertEquals("Connection successful", response.getMessage());
        verify(client, times(3)).target(anyString()); // Verify that all three APIs are tested
    }

    @Test
    void testTestConnectionFailure() throws Exception {
        // Arrange
        TestConnectionRequest request = new TestConnectionRequest();
        when(response.getStatus()).thenReturn(500);

        // Act
        TestConnectionResponse response = dataConnector.testConnection(request);

        // Assert
        assertEquals(500, response.getStatusCode());
        // Check that the message contains "Test connection failed"
        assertEquals(true, response.getMessage().contains("Test connection failed"));
    }
}