package com.radiantlogic.custom.dataconnector;

import com.radiantlogic.iddm.base.annotation.CustomConnector;
import com.radiantlogic.iddm.base.annotation.Property;
import com.radiantlogic.iddm.base.component.ManagedComponent;
import com.radiantlogic.iddm.base.logging.Logger;
import com.radiantlogic.iddm.operation.SearchOperations;
import com.radiantlogic.iddm.operation.TestConnectionOperations;
import com.radiantlogic.iddm.request.LdapSearchRequest;
import com.radiantlogic.iddm.request.TestConnectionRequest;
import com.radiantlogic.iddm.response.LdapResponse;
import com.radiantlogic.iddm.response.TestConnectionResponse;
import com.radiantlogic.iddm.base.ReadOnlyProperties;
import com.radiantlogic.iddm.base.InjectableProperties;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

@CustomConnector(metaJsonFile = "harry_potter_openapiConnector.json")
public class HarryPotterOpenapiDataConnector implements SearchOperations, TestConnectionOperations {

    private final Logger logger = Logger.getLogger(HarryPotterOpenapiDataConnector.class);

    @Property(name = "api_base_url")
    private String apiBaseUrl;

    private final BooksApi booksApi;
    private final CharactersApi charactersApi;
    private final SpellsApi spellsApi;

    public HarryPotterOpenapiDataConnector(@InjectableProperties ReadOnlyProperties properties) {
        this.apiBaseUrl = properties.getString("api_base_url");
        Client client = ClientBuilder.newClient();
        this.booksApi = new BooksApi(client, apiBaseUrl);
        this.charactersApi = new CharactersApi(client, apiBaseUrl);
        this.spellsApi = new SpellsApi(client, apiBaseUrl);
    }

    @Override
    public LdapResponse search(LdapSearchRequest request) {
        String objectType = request.getBaseDn(); // Assuming baseDn contains the object type (e.g., "books", "characters", "spells")
        String filter = request.getFilter(); // Assuming filter contains search criteria

        List<Map<String, Object>> results = new ArrayList<>();

        try {
            switch (objectType) {
                case "books":
                    results = booksApi.searchBooks(filter);
                    break;
                case "characters":
                    results = charactersApi.searchCharacters(filter);
                    break;
                case "spells":
                    results = spellsApi.searchSpells(filter);
                    break;
                default:
                    logger.warn("Unsupported object type: {}", objectType);
                    return new LdapResponse(400, "Unsupported object type");
            }
            return new LdapResponse(200, results);

        } catch (Exception e) {
            logger.error("Error during search: {}", e.getMessage(), e);
            return new LdapResponse(500, "Error during search: " + e.getMessage());
        }
    }

    @Override
    public TestConnectionResponse testConnection(TestConnectionRequest request) {
        try {
            // Test connection to all APIs
            booksApi.testConnection();
            charactersApi.testConnection();
            spellsApi.testConnection();

            return new TestConnectionResponse(200, "Connection successful");
        } catch (Exception e) {
            logger.error("Test connection failed: {}", e.getMessage(), e);
            return new TestConnectionResponse(500, "Test connection failed: " + e.getMessage());
        }
    }

    // API Clients
    @ManagedComponent
    static class BooksApi {
        private final Client client;
        private final String baseUrl;

        public BooksApi(Client client, String baseUrl) {
            this.client = client;
            this.baseUrl = baseUrl;
        }

        public List<Map<String, Object>> searchBooks(String filter) {
            // Implement search logic for books based on the filter
            // Example:  Assume filter is a search term
            String endpoint = baseUrl + "/books";
            WebTarget target = client.target(endpoint);
            if (filter != null && !filter.isEmpty()) {
                target = target.queryParam("search", filter);
            }
            Response response = target.request().get();
            if (response.getStatus() == 200) {
                // Assuming the API returns a JSON array of book objects
                List<Map<String, Object>> books = response.readEntity(List.class);
                return books;
            } else {
                throw new RuntimeException("Failed to retrieve books: " + response.getStatus());
            }
        }

        public void testConnection() {
            // Test connection to the books API endpoint
            String endpoint = baseUrl + "/books/random";
            Response response = client.target(endpoint).request().get();
            if (response.getStatus() != 200) {
                throw new RuntimeException("Books API test connection failed: " + response.getStatus());
            }
        }
    }

    @ManagedComponent
    static class CharactersApi {
        private final Client client;
        private final String baseUrl;

        public CharactersApi(Client client, String baseUrl) {
            this.client = client;
            this.baseUrl = baseUrl;
        }

        public List<Map<String, Object>> searchCharacters(String filter) {
            // Implement search logic for characters based on the filter
            String endpoint = baseUrl + "/characters";
            WebTarget target = client.target(endpoint);
            if (filter != null && !filter.isEmpty()) {
                target = target.queryParam("search", filter);
            }
            Response response = target.request().get();
            if (response.getStatus() == 200) {
                // Assuming the API returns a JSON array of character objects
                List<Map<String, Object>> characters = response.readEntity(List.class);
                return characters;
            } else {
                throw new RuntimeException("Failed to retrieve characters: " + response.getStatus());
            }
        }

        public void testConnection() {
            // Test connection to the characters API endpoint
            String endpoint = baseUrl + "/characters/random";
            Response response = client.target(endpoint).request().get();
            if (response.getStatus() != 200) {
                throw new RuntimeException("Characters API test connection failed: " + response.getStatus());
            }
        }
    }

    @ManagedComponent
    static class SpellsApi {
        private final Client client;
        private final String baseUrl;

        public SpellsApi(Client client, String baseUrl) {
            this.client = client;
            this.baseUrl = baseUrl;
        }

        public List<Map<String, Object>> searchSpells(String filter) {
            // Implement search logic for spells based on the filter
            String endpoint = baseUrl + "/spells";
            WebTarget target = client.target(endpoint);
            if (filter != null && !filter.isEmpty()) {
                target = target.queryParam("search", filter);
            }
            Response response = target.request().get();
            if (response.getStatus() == 200) {
                // Assuming the API returns a JSON array of spell objects
                List<Map<String, Object>> spells = response.readEntity(List.class);
                return spells;
            } else {
                throw new RuntimeException("Failed to retrieve spells: " + response.getStatus());
            }
        }

        public void testConnection() {
            // Test connection to the spells API endpoint
            String endpoint = baseUrl + "/spells/random";
            Response response = client.target(endpoint).request().get();
            if (response.getStatus() != 200) {
                throw new RuntimeException("Spells API test connection failed: " + response.getStatus());
            }
        }
    }
}